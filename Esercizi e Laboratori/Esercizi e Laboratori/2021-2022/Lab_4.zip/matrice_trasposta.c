/*
* Scrivete un programma che calcoli la trasposta di una generica matrice.
*
* L'operazione consiste nello scambiare le righe con le colonne.
*
* Esempio:
* |a b c| ____ |a d|
* |d e f|      |b e|
*              |c f|
*
* Per la consegna, utilizzare:
* matrice = [[1,2],[3,4],[5,6]]
*
* Utilizzare il seguente codice per stampare il risultato:
* for (int i = 0; i < colonne; i += 1){
*   for (int j = 0; j < righe; j += 1){
*       printf("%d\t", matRisultato[i][j]); 
*   }
*   printf("\n");
* }
* 
*/

#include <stdio.h>

int main()
{
    // creaimo variabili di supporto per la dimensione della matrice
    int righe = 3, colonne = 2;
    // dobbiamo definire la seconda dimensione
    int mat1[][2] = {1, 2, 3, 4, 5, 6};

    // Trasponi matrice
    int i, j, matRisultato[colonne][righe];
    for(i=0; i < righe; i++)
        for(j=0; j < colonne; j++)
            matRisultato[j][i] = mat1[i][j];

    for (int i = 0; i < colonne; i += 1){
        for (int j = 0; j < righe; j += 1){
            printf("%d ", matRisultato[i][j]); 
        }
        printf("\n");
    } 

    return 0;
}