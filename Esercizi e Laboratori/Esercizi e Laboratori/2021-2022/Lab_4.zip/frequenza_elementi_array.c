#include <stdio.h>

/*
 * Scrivete un programma che dato un array di interi positivi, calcoli quante sono le occorrenze di ogni valore presente nell'array.
 * Notate che i valori dell'array, purché positivi, 
 * possono essere grandi a piacere. 
 * Il programma deve poi stampare quanto trovato, utilizzando
 * il comando:
 * printf("il valore %d appare %d volte\n", A[i], freq[i]);
 * 
 * Per esempio se l'array è [1,1,2,3,1,2] si ottiene il seguente output:
 * il valore 1 appare 3 volte
 * il valore 2 appare 2 volte
 * il valore 3 appare 1 volte
 * 
 * Per la consegna usare l'array [2,5,6,2,7,6,6,7,7,7]
 * 
 */

/*
 * Suggerimento: 
 * usare un secondo array della stessa dimensione inizializzato a tutti 0, per tenere conto delle frequenze dei valori,
 * scorrere l'array di valori con un for e usare un secondo for annidato scorrendo lo stesso array dall'elemento successivo a quello corrente fino alla fine.
 * Ogni valore trovato uguale a quello corrente aumenta un counter ed etichetta la posizione dell'array di frequenze con -1 per segnalare che già abbiamo controllato quel valore.
 * Aggiorna l'array di frequenze con il valore del counter se il precedente valore è diverso da -1
*/

int main()
{
    // inizializzazione
    const int dim = 10;
    int A[] = {2,5,6,2,7,6,6,7,7,7}, freq[10] = {0}; // utilizza un array di frequenze della stessa dimensione dell'array di valori, inizializzato a 0
    int count;
    
    /*
        Scorro l'array e per ogni valore uso un altro ciclo per
        scorrere i valori successivi e contare la frequenza del valore preso in considerazione
        Segno ogni valore uguale a quello preso in esame con -1 nell'array di frequenze per ricordare che ho già controllato
        e sfrutto questa cosa per ottimizzare il programma e stampare quello che voglio
    */

    for(int i=0; i<dim; i+=1)
    {
        count = 1;  // reset del counter ad ogni iterazione

        if(freq[i]!=-1) {
            for(int j=i+1; j<dim; j+=1) 
            {
                if(A[i]==A[j])
                {
                    count+=1;
                    freq[j] = -1;
                }
            }

            freq[i] = count;
        }
    }
    
    // Stampa
    for(int i=0; i<dim; i+=1)
        if(freq[i]!=-1)
            printf("il valore %d appare %d volte\n", A[i], freq[i]);
            
    return 0;
}