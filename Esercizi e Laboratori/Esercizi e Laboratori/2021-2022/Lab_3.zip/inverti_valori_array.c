#include <stdio.h>

/*
 * Scrivete un programma che dato un array di interi, inverta (riordini) i valori dell'array
 * scambiando ogni valore con il suo corrispondente partendo dal fondo. 
 * Ad esempio l'inverso dell'array [1,2,4] è [4,2,1]. 
 * Il programma deve stampare l'array aggiornato, utilizzare
 * printf("[");
 * for (int i = 0; i < dim; i+=1)
 *     printf(" %d ",A[i]);
 * printf("]");
 *
 * Per esempio se l'array è [1,2,3,4] si ottiene il seguente output: 
 * [ 4 3 2 1 ]
 *  
 * Per la consegna utilizzare l'array [1,2,3,4,5,6,7,8,9,10]
 * 
*/

/*
 * Suggerimento:
 * sfruttare una variabile temporanea per lo scambio tra valori e 
 * utilizzare in maniera intelligente la variabile i, usata per scorrere gli indici dell'array, in modo da poter accedere agli ultimi valori in senso decrescente
*/

void inverti(int *A, int dim);
void stampa_array(int *A, int dim);


int main()
{
    const int dim = 10;
    int A[] = {1,2,3,4,5,6,7,8,9,10};
    int tmp; 
    
    inverti(A, dim);
    stampa_array(A, dim);

    return 0;
}


void inverti(int *A, int dim) {

    int tmp; // utilizza una variabile per lo scambio tra elementi
    for (int i = 0; i < dim/2; i+=1) { // scorre l'array scambiando gli elementi
        tmp = A[i];
        A[i] =A[dim-1-i]; // dim = 10, quindi l'ultimo indice è dim - 1 (9), dim-1-i scorre progressivamente dall'ultimo indice al primo 
        A[dim-1-i] = tmp;
    }
    
}


void stampa_array(int *A, int dim) {

    printf("[");
    for (int i = 0; i < dim; i+=1)
        printf(" %d",A[i]);
    printf(" ]\n");

}
