#include <stdio.h>

/*
* Scrivete un programma che trovi l'indice del minimo e
* del il massimo valore di un array di interi.
*
* Il programma deve stampare i valori trovati. Utilizzare:
* printf("Valore minimo: array[%d] -> %d\n", min_indice, array[min_indice]);
* printf("valore massimo: array[%d] -> %d", max_indice, array[max_indice]);
*
* Per la consegna utilizzare il seguente array: [3, 5, 1, 7, 0, 9, 4, 6, 2, 8]
*/

/*
* Suggerimento: per trovare i valori massimi e minimi è possibile utilizzare
* un ciclo for che passa attraverso tutti gli elementi dell'array.
*/

int main(void)
{
    /*
        Per comodità di utilizzo, definiamo una costante N con la lunghezza
        dell'array.
    */
    const int N = 10;
    int array[] = {3, 5, 1, 7, 0, 9, 4, 6, 2, 8};
    
    /*
        Utilizziamo un ciclo for che passa attraverso tutti gli elementi
        dell'array. Per ogni elemento controlla se questo sia minore del
        più piccolo elemento trovato o maggiore del più grande elemento
        trovato. Notate che stiamo assumendo di seguito
        che l'array non sia vuoto (altrimenti la stampa di
        array[max_indice] e array[min_indice] genererebbe un errore). 
    */
    
    int min_indice = 0, max_indice = 0; 
    for (int i = 0; i < N; i += 1){
        if (array[i] < array[min_indice]){
            min_indice = i;
        }
        else if (array[i] > array[max_indice]){
            max_indice = i;
        }
    }
    
    /*
        Terminiamo con la stampa.
    */
    printf("Valore minimo: array[%d] -> %d\n", min_indice, array[min_indice]); 
    printf("valore massimo: array[%d] -> %d", max_indice, array[max_indice]);
    
    return 0;
}
