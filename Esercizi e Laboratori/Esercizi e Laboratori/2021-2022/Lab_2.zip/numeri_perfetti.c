#include <stdio.h>

/*
* Scrivete un programma che trovi tutti i numeri perfetti tra due estremi compresi. Sia estremi che i numeri trovati dovranno essere interi.
* Un numero perfetto si definisce tale quando la somma di tutti i suoi divisori eccetto se stesso è uguale al numero stesso.
*
* Il programma deve stampare i valori trovati, utilizzare
* printf("Il numero %d è perfetto\n", limite_inferiore);
*
* Per la consegna utilizzare il seguenti limiti:
* limite_inferiore = 4
* limite_superiore = 30
*/

/*
* Suggerimento: utilizzare una funzione per calcolare quando un numero è perfetto e un ciclo per scorrere tra gli estremi richiamando la funzione su ogni numero compreso
*/

int perfectNumber(int x); // inserisce il prototipo della funzione 

int main()
{
    // inizializzazione
    int limite_inferiore = 4, limite_superiore = 30;
    
    // scorre dal limite inferiore al superiore e controlla ogni numero, se perfetto lo stampa

    while (limite_inferiore <= limite_superiore){

        if ( perfectNumber(limite_inferiore) )
            printf("Il numero %d è perfetto\n", limite_inferiore);

        limite_inferiore+=1;

    }
    
    return 0;
}


int perfectNumber(int x){
    int somma = 0; // utilizza una variabile per calcolare la somma dei divisori eccetto il numero stesso
    
    // calcola la somma
    for (int i = 1; i<x; i+=1){
        if (x%i == 0)
            somma += i; // equivale a somma = somma + i;
    }
    
    // confronta e ritorna se il numero è perfetto o meno (0=Falso, 1=Vero)
    if (somma == x)
        return 1;
    else
        return 0;
}
