#include <stdio.h>

/*
 * Dichiarare due variabili intere x,y, stampare la loro somma e 
 * la loro differenza. 
 * Ad es. se x=3 e y=5 stampa
 * x+y=8
 * x-y=-2 
 */

int main() {

    int x; 
    int y; //equivalentemente potevo scrivere int x,y; 
    int somma;

    x = 3; 
    y = 5;
    somma = x + y;

    printf("x+y=%d\n", somma);
    printf("x-y=%d\n", x-y); /* si può indicare direttamente
                            l'espressione x-y senza dover salvare 
                            prima il risultato in una variabile */
    
    //printf("x+y=%d\nx-y=%d\n", somma, x-y); // comando equivalente ai
                        // due sopra, si può scrivere tutto con un solo comando printf
}


