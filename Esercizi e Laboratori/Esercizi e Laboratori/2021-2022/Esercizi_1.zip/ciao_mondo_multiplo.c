#include <stdio.h>

/*
 * Il programma stampa x volte "Ciao Mondo!"
 * Es. se x = 3
 * Ciao Mondo!
 * Ciao Mondo!
 * Ciao Mondo!
 */

int main () {

    int x = 3;
    int i = 0; //conta quante volte abbiamo scritto Ciao Mondo!

    while (i < 3) { // poichè sotto abbiamo i=i+1, il ciclo 
                    // viene eseguito 3 volte (i=0,1,2)
        printf("Ciao Mondo!\n");
        i = i + 1; // adesso abbiamo scritto "Ciao Mondo!" una volta in più
    }
    
}
