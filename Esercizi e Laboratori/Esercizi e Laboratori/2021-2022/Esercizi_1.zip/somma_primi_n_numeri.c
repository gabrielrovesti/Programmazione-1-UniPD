#include <stdio.h>

/*
 * Calcolare la somma dei primi n numeri naturali e stamparla a video
 * Ad es. se n=4 stampa
 * 10
 */

int main () {

    int n = 4;
    int i;
    int somma = 0;
    
    for (i=1; i<=n; i=i+1) {
        somma = somma + i; // somma adesso equivale alla somma dei primi i numeri
    }

}