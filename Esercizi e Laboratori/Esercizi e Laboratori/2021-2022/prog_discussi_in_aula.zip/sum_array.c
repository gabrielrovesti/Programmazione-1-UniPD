#include <stdio.h>

/* 
 * Calcolare la somma degli elementi di un array di interi. 
 * Ad es. se l'array è {2,6,1}, stampa
 * 9
 * 
 */


int somma(int *X, int size) {
    /*
        PRE l'array X ha dimensione size
        POST restituisce X[0]+...+X[size-1] (restituisce la somma dei valori dell'array)
    */
    int sum = 0, i=0;
    for (i=0; i<size; i=i+1) { 
        //INV sum=0+X[0]+...+X[i-1]
        sum += X[i];
    }
    return sum;
    //i==size -> sum=X[0]+...+X[size-1] 
}


int main(void) {
    
    int sum;
    int x[3] = {2,6,1};

    sum = somma(x, 3);

    /* stampa del risultato */ 
    printf("somma=%d\n", sum);

}
