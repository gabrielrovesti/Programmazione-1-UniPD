#include <stdio.h>

#define NUM_COLS 3

void stampa0(int a[][NUM_COLS], int righe) {

    for (int i = 0; i < righe; i=i+1) {
      for (int j = 0; j < NUM_COLS; j+=1) { 
         printf("%d ", a[i][j]);
      } 
      printf("\n"); 
   }
   printf("\n");                                       
} 


void stampa1(int righe, int colonne, int a[righe][colonne]) {

    for (int i = 0; i < righe; i+=1) {
      for (int j = 0; j < colonne; ++j) { 
         printf("%d ", a[i][j]);
      } 
      printf("\n"); 
   } 
   printf("\n");                                  
} 


void stampa2(int* a[], int righe, int colonne) {

    for (int i = 0; i < righe; i+=1) {
      for (int j = 0; j < colonne; ++j) { 
         printf("%d ", a[i][j]);
      } 
      printf("\n"); 
   }
   printf("\n");                                       
}


void stampa3(int* a, int righe, int colonne) {

    for (int i = 0; i < righe; i+=1) {
      for (int j = 0; j < colonne; ++j) { 
         printf("%d ", *(a+i*colonne+j));
      } 
      printf("\n"); 
   }
   printf("\n");
}


int main(void) {

   int a[][NUM_COLS] = { {1,2,3}, {4,5,6} };
   int *p[] = {a[0], a[1]}; //vettore di puntatori ad intero inizializzato con i puntatori ai vettori riga di a
   int *pp = a[0]; //puntatore al primo elemento della prima riga della matrice

   stampa0(a, 2);
   stampa1(2, NUM_COLS,a);
   stampa2(p, 2, NUM_COLS);
   stampa3(pp, 2, NUM_COLS);

}
