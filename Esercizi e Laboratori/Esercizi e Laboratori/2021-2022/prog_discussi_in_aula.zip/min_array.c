#include <stdio.h>

/* 
 * Calcolare l'elemento di valore minimo in un array 
 * di 5 interi. 
 * Ad es. se l'array è {2,6,4,5,1}, stampa
 * 1
 * 
 */


int minimo(int *X, int size) {
    /*
        PRE size>0, l'array X ha dimensione size
        POST per ogni 0<=j<size. min<=X[j] (min è il minimo dell'array)
    */

    int min = X[0], i = 0;
    for (i=1; i<size; i=i+1) { 
        /*
            INV per ogni 0<=j<i. min<=X[j] (min è il minimo fino ad X[i])
        */
        if(X[i]<min)
            min = X[i];
    }
    // i==size
    return min;
    /*
        per ogni 0<=j<size. min<=X[j] (min è il minimo dell'array)
    */
}


int main(void) {
    
    int min;
    int x[5] = {2,6,4,1,5};

    min = minimo(x, 5);

    /* stampa del risultato */ 
    printf("min=%d\n", min);

}
