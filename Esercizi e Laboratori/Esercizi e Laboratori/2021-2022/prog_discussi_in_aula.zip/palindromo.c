#include<stdio.h>

/*
 * Dato un array di interi di lunghezza N, scrivere un programma che stampa
 * "L'array è palindromo" se l'array è palindromo o "L'array non è palindromo" se non lo è.
 * Un array è definito palindromo se invertendolo rimane uguale (es. [1, 2, 3, 2, 1] è palindromo)
 * ATTENZIONE: l'input non è più fisso, la dimensione N e i valori dell'array saranno forniti come input. 
*/

int palindromo(int array[], int n) {
    /* 
    PRE: array ha dimensione n
    Calcola se array è palindromo, ovvero se 
    per 0<=j<n, array[j]==array[n-1-j].
    POST: restituisce 1 se l'array è palindromo
                      0 altrimenti.
    */
    //INV Per 0<=j<i, array[j]==array[n-1-j]
    for(int i = 0; i<n/2; i+=1){
        if(array[i] != array[n-1-i]){
            return 0;
            // array[i] != array[n-1-i] -> array non palindromo
        }
    }
    /* 
        i=n/2, quindi per ogni 0<=j<n/2 array[j]==array[n-1-j].  
        Perciò per j=n/2-1 array[n/2-1]==array[n-1-n/2+1]<=> 
        array[n/2-1]==array[n-n/2]. Per simmetria dell'operatore ==, 
        abbiamo dimostrato la proprietà per 
        j>=n-n/2 (ovvero per n/2+1 valori di j), quindi in 
        totale per n/2-1+n/2+1=n/2+n/2 valori di j. (Ne manca qualcuno?) 
        Se n%2==0 n/2+n/2==n e la proprietà vale per tutti i valori dell'array, quindi la POST è verificata. 
        Se n%2==1 n/2+n/2+1==n ma array[n/2]==array[n-1-n/2] <=> array[n/2]==array[n/2+1-1], la POST è quindi verificata anche in questo caso. 
    */
    return 1;
}

int palindromo2contatori(int array[], int n) {
/* 
    PRE: array è formato da n interi.
    Calcola se array è palindromo.
    POST: restituisce 1 se l'array è palindromo
                      0 altrimenti.
*/
    for(int i = 0, j=n-1; i<j; i+=1, j-=1){
        if(array[i] != array[j]){
            return 0;
        }
    }
    return 1;
}

int main(){
    int N;
    //leggere da input grandezza array
    scanf("%d", &N);

    int array[N];

    //leggere da input dati array
    for(int i = 0; i < N; i++){
        scanf("%d", array+i);
    }

    if(palindromo(array, N) == 1){
        printf("L'array è palindromo\n");
    } else printf("L'array non è palindromo\n");
    
}