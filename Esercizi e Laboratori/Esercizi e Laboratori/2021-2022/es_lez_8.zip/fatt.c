#include <stdio.h>

int fattoriale(int n) {

    if(n==0)
        return 1;
    return n*fattoriale(n-1);

}


int main(void) {

    printf("%d\n",fattoriale(4));

}
