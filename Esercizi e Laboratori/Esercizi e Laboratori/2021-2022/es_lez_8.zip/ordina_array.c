#include <stdio.h>

/*
* Scrivete un programma che ordini un array di numeri interi in ordine
* crescente.
*
* Il programma deve stampare l'array ordinato al termine dell'esecuzione.
* Utilizzare: printf("Array[%d] : %d\n", i, array[i]);
*
* Per la consegna, utilizzare il seguente array:
* [3, 5, 7, 1, 2, 9, 4, 6, 0, 8]
*/

/*
* Suggerimento: per ordinare l'array è possibile spostare i suoi
* elementi utilizzando due cicli for, uno interno all'altro. Il
* ciclo interno trova il valore minimo contenuto nell'array. Il
* ciclo esterno permette di spostare l'elemento minimo all'inizio
* dell'array.
*/

void stampa(int *array, int N);
void scambia(int *x, int *y);
void ordina(int *X, int size);
int trova_minimo(int *ar, int size);


void stampa(int *array, int N) {

    for(int i = 0 ; i < N ; i += 1){
        printf("Array[%d] : %d\n", i, array[i]);
    }
}

void scambia(int *x, int *y) {

    int temp = *x;
    *x = *y;
    *y = temp;
}


/* trova l'indice di valore minimo dell'array di interi X di dimensione size */
int trova_indice_minimo(int *ar, int size) {
    /*
        PRE size>0, ar ha dimensione size
        POST restituisce indice_min. per ogni 0<=j<size. ar[indice_min]<=ar[j] 
     */
    int indice_min = 0;
    for(int i=1; i<size; i+=1) {
        /*
            INV per ogni 0<=j<i. ar[indice_min]<=ar[j]
        */
        if(ar[i] < ar[indice_min])
            indice_min = i;
    }
    return indice_min;
    /*
        i=size -> per ogni 0<=j<size. ar[indice_min]<=ar[j]
     */
}

/* ordina l'array di interi X di dimensione size */
void ordina(int *X, int size) {
/*
    PRE X ha dimensione size
    POST per ogni 0<=j<size-1. X[j]<=X[j+1] (X è ordinato 
    in modo crescente)
 */
    int indice_min; 
    for(int i=0; i<size-1; i+=1) {
        /*
            INV per ogni 0<=j<i, j<=z<size-1. X[j]<=X[z] 
         */
        indice_min = trova_indice_minimo(X+i, size-i);
        /*
            per ogni 0<=l<size-i. X[i+indice_min]<=X[i+l]
         */
        scambia(X+i, &X[indice_min+i]);
        /*
            per ogni 0<=l<size-i. X[i]<=X[i+l] ovvero
            per ogni i<=l<size. X[i]<=X[l]
         */
    }
    /*
        per ogni 0<=j<size-1, j<=z<size-1. X[j]<=X[z] 
        per ogni 0<=j<=z<size-1, X[j]<=X[z] -> per ogni 0<=j<size-1, X[j]<=X[j+1]
    */
}

int main(void)
{
    /*
        Per comodità di utilizzo, definiamo una costante N con la lunghezza
        dell'array.
    */
    const int N = 10;
    int array[] = {3, 5, 7, 1, 2, 9, 4, 6, 0, 8};
    stampa(array, 10);
    ordina(array, 10);
    printf("\nArray Ordinato\n");
    stampa(array, 10);
    
    return 0;
}
