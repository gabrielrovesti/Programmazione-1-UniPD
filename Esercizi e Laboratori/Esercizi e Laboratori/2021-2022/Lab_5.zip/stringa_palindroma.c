
#include <stdio.h>

/* 
* Scrivere un programma che dato in input una stringa, verifichi con una funzione ricorsiva se è palindroma.
* Il programma deve poi stampare quanto trovato, utilizzare:
* if ( stringa_palindroma == 1)
*     printf("%s palindroma\n",S);
* else
*     printf("%s non palindroma\n",S);
*/

/*
* Suggerimento:
* Passare un indice che parte dal primo elemento come parametro aggiuntivo alla funzione.
* Utilizzare l'indice e la dimensione della stringa per confrontare i caratteri (primo con ultimo, secondo con penultimo e così via),
* fin quando non si arriva a metà.
*/

// PRE: S stringa di lunghezza dim, i indice del primo elemento
int palindroma(char* S,int dim,int i){
    if(i == dim/2)
        return 1;
    if(*(S+i) != *(S+dim-1-i))
        return 0;
    return palindroma(S,dim,i+1);
}
//POST: ritorna 1 se la stringa è palindroma, 0 altrimenti

/*

Versione alternativa:
- necessita il passaggio di len - 1 come parametro per dim
- decrementa dim ogni volta

int palindroma2(char* S,int dim,int i){
    if(i >= dim)
        return 1;
    if(S[i] != S[dim])
        return 0;
    return palindroma2(S,dim-1,i+1);
}


Versione alternativa complessa:
- necessita il passaggio di len - 1 come parametro per dim
- non usa l'indice i
- sposta il puntatore alla stringa e decrementa dim di 2 per confrontare i caratteri

int palindroma3(char* S,int dim){
    if(dim <= 0)
        return 1;
    if(*S != *(S+dim))
        return 0;
    return palindroma3(S+1,dim-2);
}
*/

int main()
{
    int len;
    scanf("%d",&len);
    char S[len];
    scanf("%s",S);
    int i = 0;
    
    int stringa_palindroma = palindroma(S,len,i);
    
    if ( stringa_palindroma == 1)
        printf("%s palindroma\n",S);
    else
        printf("%s non palindroma\n",S);
    

    return 0;
}
