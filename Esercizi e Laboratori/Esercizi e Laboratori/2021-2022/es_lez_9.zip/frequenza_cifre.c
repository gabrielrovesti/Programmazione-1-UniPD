#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

/*
* Scrivete una funzione che, dato un numero intero, calcoli la
* frequenza di ciascuna cifra. Nel main stampare a video tali
* frequenze. 
*
* Es. 1242213 stampa
*
* Numero: 1242213 
* frequenza 0: 0
* frequenza 1: 2
* frequenza 2: 3
* frequenza 3: 1
* frequenza 4: 1
* frequenza 5: 0
* frequenza 6: 0
* frequenza 7: 0
* frequenza 8: 0
* frequenza 9: 0
* 
*/

/*
* Suggerimento 1: per estrarre la cifra più a destra usare 
* gli operatori di modulo e divisione. 
*
* Suggerimento 2: n % 10 restituisce la prima cifra da 
* destra di n. Per estrarre la seconda cifra più a destra, 
* dividere n per 10 prima di riapplicare l'operazione di
* modulo.
*/

void test_contaCifre(void);
int confronta_array(int *X, int *Y, int dim);
void contaCifre(int n, int frequenza[]);
void stampa_array(int freq[], int dim);

void contaCifre(int n, int frequenza[]) {
    /*
        PRE: 
        POST: per ogni i frequenza[i]==k se e solo se la
        cifra i compare k volte in n.
     */
    for(int i=0; i<10; i+=1) {
        frequenza[i] = 0;
    }
    if (n==0)
        frequenza[0] = 1;
    if (n<0)
        n = -1*n;
    while(n>0) {
        frequenza[n % 10] += 1;
        n = n / 10;
    }
}

void test_contaCifre(void) {

    int frequenza[10] = {0};
    int res[10] = {0};

    res[1] = 1; res[2]=2; res[3]=1;
    contaCifre(1223, frequenza);
    assert(confronta_array(frequenza, res, 10)==1);

    res[1] = 1; res[2]=2; res[3]=1;
    contaCifre(-1223, frequenza);
    assert(confronta_array(frequenza, res, 10)==1);

    res[0] = 1; res[1]=0; res[2]=0; res[3]=0; res[4]=0; 
    res[5]=0; res[6]=0; res[7]=0; res[8]=0; res[9]=0;
    contaCifre(0, frequenza);
    assert(confronta_array(frequenza, res, 10)==1);

/*
    res[1] = 1; res[2]=2; res[3]=1;
    contaCifre(-1223, frequenza);
    assert(confronta_array(frequenza, res, 10)==1);
*/

    printf("Test funzione contaCifre. tutti i test passati\n");

}


int main(int argc, char *argv[]) {

    test_contaCifre(); return 0;

    int n;
    scanf("%d", &n);

    int frequenza[10] = {0};
    contaCifre(n, frequenza);

    stampa_array(frequenza, 10);

    return 0;
}


int confronta_array(int *X, int *Y, int dim) {
    /*
        Confronta due array di interi della stessa dimensione elemento ad elemento: l'i-esimo 
        del primo con l'i-esimo del secondo, per i
        che varia su tutti gli elementi dell'array.
        Restituisce 1 se tutti gli elementi sono uguali
                    0 altrimenti
    */
   for(int i=0; i<dim; i+=1) {
       if (X[i]!=Y[i])
        return 0; // i due array non sono uguali
   }
   return 1; 
}

void stampa_array(int freq[], int dim) {

    for(int i=0; i<dim; i+=1) {
        printf("frequenza %d: %d\n", i, freq[i]);
    }

}
