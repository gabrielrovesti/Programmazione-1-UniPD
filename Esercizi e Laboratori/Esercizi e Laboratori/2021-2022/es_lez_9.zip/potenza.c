#include <stdio.h>

int potenza(int base, int esp) {
    /*
        PRE: esp>=0, base!=0
        POST: restituisce base^esp 
    */
    if (esp==0) {
        return 1;
    } else {
        return base*potenza(base, esp-1);
    }

}


int main(void) {

    printf("%d\n", potenza(2,3));

}
