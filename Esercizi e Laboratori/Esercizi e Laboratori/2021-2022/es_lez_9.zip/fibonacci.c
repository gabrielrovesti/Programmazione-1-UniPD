#include <stdio.h>

int fibonacci(int n) {
    /*  PRE: n>=0
        POST: Fibonacci(n), dove 
        Fibonacci(0) = 0
        Fibonacci(1) = 1
        per n>1. Fibonacci(n) = Fibonacci(n-1) = Fibonacci(n-2)
    */
    if(n<=1)
        return n;
    return fibonacci(n-1) + fibonacci(n-2);
}


int main(void) {

    for(int i=1; i<50; i+=1)
        printf("fib(%d)=%d\n", i, fibonacci(i));

}
