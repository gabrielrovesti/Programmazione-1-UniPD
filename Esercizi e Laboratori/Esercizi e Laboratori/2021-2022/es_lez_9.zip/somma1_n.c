#include <stdio.h>

int somma1_n(int n) {
    //PRE: n>=0
    //POST: n + n-1 + ... + 1
    if (n<=0)
        return 0;
    return n + somma1_n(n-1);
}

int main(void) {

    printf("%d\n", somma1_n(4));

}
