# Tutorato-Programmazione-2018-19
Repository per gli esercizi svolti al Tutorato di Programmazione per l'a.a. 2018/19

Tutor:
* Agatea Riccardo (riccardo.agatea@studenti.unipd.it)
* Carnovalini Filippo (filippo.carnovalini@dei.unipd.it)
* Micheletti Christian (christian.micheletti@studenti.unipd.it)
* Schimmenti Vincenzo Maria (vincenzomaria.schimmenti@studenti.unipd.it)
