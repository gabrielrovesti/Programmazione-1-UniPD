#include<iostream>
#include "BST.h"
using namespace std;
//contiene le implementazioni delle 7 funzioni richieste

void stampa_l(nodo* r){
    if(r){
        cout<<r->info;
        cout<<'(';
        stampa_l(r->left);
        cout<<',';
        stampa_l(r->right);
        cout<<')';
    }
    else
        cout<<'_';
}

nodo* insert(nodo* r, int x){
    if(!r) return new nodo(x);
    if(x<r->info)
        r->left=insert(r->left, x);
    else
        r->right=insert(r->right, x);
    
    return r;
}

bool search (nodo* r, int x){
    if(!r) return false;
    if(r->info==x) return true;

    return search(r->left, x) || search(r->right, x);
}

nodo* max(nodo* r){
    return r->right ? max(r->right) : r;
}

nodo*& min(nodo*& r){
    return r->left ? min(r->left) : r;
}

int altezza(nodo* r){
    if(!r || !r->left && !r->right){
        return 0;
    }
    int lHeight = altezza(r->left);
    int rHeight = altezza(r->right);
    
    return 1+max(lHeight,rHeight);
}

int altMin(nodo* r){
    if(!r || !r->left && !r->right){
        return 0;
    }
    int lHeight = altMin(r->left);
    int rHeight = altMin(r->right);
    
    if(r->left && r->right){
        return 1+min(lHeight,rHeight);
    }
    if(r->left)
        return 1+lHeight;
    else
        return 1+rHeight;
}

void elim(nodo*& r, int x){
    if(r){
        if(r->info==x){
            if(!r->left && !r->right) 
                r=NULL;
            else if(r->right)
                r=r->left;              
            else if(r->left)
                r=r->right;
            else
            {
                nodo*& y=min(r->right);
                nodo *p=y;
                y=y->right;
                p->left=r->left;
                r->right=NULL;
                r->left=NULL;
            }
        }
        else if(x<r->info)
            elim(r->left, x);
        else
            elim(r->right,x);
    }
}

nodo* elim1(nodo* r, int x){
    if(!r) return 0;

    if(r->info==x){
        if(!r->left && !r->right)
            return 0;
        else if(!r->left)
            return r->right;
        else if(!r->right)
            return r->left;  
        else{
            int info=min(r->right)->info;
            r->right=elim1(r->right, info);
            r->info=info;
            return r;
        }  
    }
    else if(x<r->info)
    {
        r->left=elim1(r->left, x);
        return r;
    }
    else
    {
        r->right=elim1(r->right, x);
        return r;
    }
}