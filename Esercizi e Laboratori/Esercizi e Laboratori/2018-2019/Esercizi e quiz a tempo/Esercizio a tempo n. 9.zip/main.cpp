#include "BST.h"
#include<iostream>
using namespace std;

main()
{
    //prepara un albero iniziale non triviale
    nodo* r=new nodo(15, new nodo(7), new nodo(19));
    r->left->right=new nodo (9, new nodo(8));
    r->right->right=new nodo(25, new nodo(22));
  
    cout<<"start"<<endl;

    int in;
    bool stop=false;
    while(!stop)
    {
        cin>>in;

        switch(in){
            case 0:
                stop=true;
                break;
            case 1:
                //stampa
                stampa_l(r);
                cout<<endl;
                break;
            case 2:
                //inserisci nodo e stampa
                cin>>in;
                stampa_l(r=insert(r, in));
                cout<<endl;
                break;
            case 3:
                //stampa se nodo e' presente
                cin>>in;
                cout<< "valore "<<in<<(search(r, in) ? " presente" : " non presente")<<endl;
                break;
            case 4:
                //stampa min o max
                cin>>in;
                if(in==1)
                    cout<<min(r)->info<<endl;
                else
                    cout<<max(r)->info<<endl;
                break;
            case 5:
                //stampa altezza7
                cout<<altezza(r)<<endl;
                break;
            case 6:
                //stampa lunghezza minima tra root e foglia (altezza minima)
                cout<<altMin(r)<<endl;
                break;
            case 7:
                //rimuovi elemento
                cin>>in;
                stampa_l(r=elim1(r,in));
                cout<<endl;
                break;
        }
    }

    cout<<"end"<<endl;
}