Questi esercizi sono tratti dal libro "Programmazione consapevole (semplice è bello)", di Gilberto Filè.
Non garantisco che siano corretti, sebbene siano stati più volte controllati.
Notare che alcuni esercizi potrebbero essere sprovvisti della correttezza.
Altri esercizi potrebbero non essere presenti.

Riccardo Bucco